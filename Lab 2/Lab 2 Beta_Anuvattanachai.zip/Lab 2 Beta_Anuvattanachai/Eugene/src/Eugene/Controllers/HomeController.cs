﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Eugene.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Date = DateTime.Now;
            //var outsideTemp = 42;
            //ViewBag.Greeting = "The current date/time in Eugene is " + hour + ". " ;
            //ViewBag.Temp = "The current temperature is " + outsideTemp;
            ViewBag.Temp = 48;
            return View();
        }

        public IActionResult About()
        {
            //ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View("Contact");
        }

        public IActionResult History()
        {
            return View("History");
        }

        //public IActionResult TodayNews()
        //{
        //    return Redirect("TodayNews");
        //}
    }
}
