﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Eugene.Models;



namespace Eugene.Controllers
{
    public class NewsController1 : Controller
    {
    
        public IActionResult TodayNews()
        {
            var viewModel = new News()
            {
                Title = "Election",
                Story = "Inauguration"
            };
           
            return View(viewModel);
        }

        public IActionResult Archive()
        {
            ViewData["Message"] = "your application Archive page";
            return View();
        }
    }
}
