﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Eugene.Models;



namespace Eugene.Controllers
{
    public class NewsController : Controller
    {

        public IActionResult TodayNews()
        {
            var news = new News();
            {
                news.Title = "Woman march";
                news.Story = "People gathered in Portland's Tom McCall Waterfront Park and marched through downtown, Jan. 21, 2017, in local support for the Women's March on Washington following the election of Donald Trump. Beth Nakamura/ Staff";

            }
            return View(news);
        }

        public IActionResult Archive()
        {
            //ViewData["Message"] = "your application Archive page";
            return View();
        }
    }
}
