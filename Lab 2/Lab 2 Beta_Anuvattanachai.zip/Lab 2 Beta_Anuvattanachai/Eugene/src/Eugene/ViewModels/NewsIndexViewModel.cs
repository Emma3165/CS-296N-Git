﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Eugene.Models;

namespace Eugene.ViewModels
{
    public class NewsIndexViewModel
    {
        public News news { get; set; }
    }
}
