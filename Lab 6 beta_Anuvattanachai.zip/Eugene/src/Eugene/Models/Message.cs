﻿using System;
using System.Collections.Generic;
using Eugene.Models;
using System.Threading.Tasks;

namespace Eugene.Models
{ 
    public class Message
    {
        public int Name { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }

        public List<Member> Members { get { return Members; } }
        public DateTime Date { get; set; }
        public string From { get; set; }
        public string Topic { get; set; }
    }
}
