﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Eugene.Models;
using Eugene.Controllers;
using Xunit;

namespace Eugene.Tests
{
    public class MessageTest
    {

        [Fact]
        public void CanGetMessges()
        {
            //Arrange
            FakeMessageRopository repo = new FakeMessageRopository();
            MessageController controller = new MessageController(repo);

            //Act
            List<Message> messages = controller.List().ViewData.Model as List<Message>;

            //Assert
            Assert.Equal(repo.GetAllMessages()[1].Date, messages[1].Date);
            Assert.True (repo.GetAllMessages()[0].From == "Paul Jones");
        }

        [Fact]
        public void CanGetMessgesByMember()
        {
            //Arrange
            FakeMessageRopository repo = new FakeMessageRopository();
            MessageController controller = new MessageController(repo);
            Member Sandra = new Member() { Name = "Sandra Bullocks", Email = "ssmith@gmail.com" };

            //Act
            List<Message> messages = controller.MessagesByMember(Sandra).ViewData.Model as List<Message>;

            //Assert
            Assert.Equal(repo.GetMessagesByMember(Sandra)[1].Date, messages[1].Date);
            
        }




    }













}
