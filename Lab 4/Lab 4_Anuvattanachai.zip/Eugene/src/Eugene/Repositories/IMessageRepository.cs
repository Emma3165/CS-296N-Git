﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Eugene.Repositories;
using Eugene.Models;

namespace Eugene.Repositories
{
    public interface IMessageRepository
    {
        List<Message> GetMessagesBySubject();
        List<Message> GetMessagesByTopic();
    }
}
