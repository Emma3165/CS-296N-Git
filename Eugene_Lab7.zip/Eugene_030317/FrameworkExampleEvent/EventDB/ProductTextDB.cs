﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ToolsCSharp;
using DBBase = ToolsCSharp.BaseTextDB;


namespace EventClasses
{
  public class ProductTextDB : DBBase, IReadDB, IWriteDB
  {












  }
}
