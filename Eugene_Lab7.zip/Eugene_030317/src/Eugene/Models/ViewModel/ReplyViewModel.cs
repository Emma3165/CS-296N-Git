﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eugene.Models.ViewModel
{
    public class ReplyViewModel
    {
        
        public int MessageID { get; set; }

        public Reply MessageReply { get;  set;}
        


    }
}
